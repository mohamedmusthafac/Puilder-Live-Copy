<?php

namespace EAddonsCopyPaste\Modules\CopyPaste;

use EAddonsForElementor\Base\Module_Base;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Copy_Paste extends Module_Base {

    public function __construct() {
        parent::__construct();
    }
    
}
